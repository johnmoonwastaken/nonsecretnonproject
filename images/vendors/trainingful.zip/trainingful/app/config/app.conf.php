<?php

// Remember to overwrite elements of this file that are unique to your local environment
// Do this by creating an app-local.conf.php file and overwrite ONLY individual elements

$config['db'] = array(
		'host' => 'startyl.startlogicmysql.com',
		'port' => '3306',
		'user' => 'traininghub',
		'pass' => 'hubble',
		'name' => 'traininghub');