<?php include('page-head.inc.php'); ?>
	
	<body class="left-sidebar">
	
		<?php include('header-start.inc.php'); ?>
		<?php include('header-end.inc.php'); ?>
		
		<!-- Main -->
		<div class="wrapper">
			<div class="container" id="main">
				<div class="row oneandhalf">
		
				<?php include('search-filter.inc.php'); ?>
				<?php include('search-results.inc.php'); ?>
		
				</div>
			</div>
		</div>
		
		
		<?php include('footer-start.inc.php'); ?>
		<?php include('footer-end.inc.php'); ?>
	</body>
	
<?php include('page-foot.inc.php'); ?>
