
		
					<div class="3u">

						<!-- Sidebar -->
							<section id="sidebar">
								<section>
									<header>
										<h3>Filter</h3>
									</header>
									<p>Lorem ipsum dolor sit amet consectetur et sed adipiscing elit. Curabitur et vel 
									sem sit amet dolor neque semper magna. Lorem ipsum dolor sit amet consectetur et dolore 
									adipiscing elit. Curabitur vel sem sit.</p>
									<ul class="actions">
										<li><a href="#" class="button">Magna amet nullam</a></li>
									</ul>
								</section>
								<section>
									<a href="#" class="image featured"><img src="images/pic07.jpg" alt="" /></a>
									<header>
										<h3>Commodo lorem varius</h3>
									</header>
									<p>Lorem ipsum dolor sit amet consectetur et sed adipiscing elit. Curabitur et vel 
									sem sit amet dolor neque semper magna. Lorem ipsum dolor sit amet consectetur et dolore 
									adipiscing elit. Curabitur vel sem sit.</p>
									<ul class="actions">
										<li><a href="#" class="button">Ipsum sed dolor</a></li>
									</ul>
								</section>
							</section>
				
					</div>
					