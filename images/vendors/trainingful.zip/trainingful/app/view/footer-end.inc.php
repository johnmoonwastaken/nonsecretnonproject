			<div id="copyright" class="container">
				<ul class="menu">
					<li><a href="#">About Us</a></li>
					<li><a href="#">Contact</a></li>
					<li><a href="#">Media</a></li>
					<li><a href="#">Careers</a></li>
					<li><a href="#">Investors</a></li>
			
				</ul>
				<ul class="menu">
					<li>&copy; 2014 Trainingful.com. All rights reserved.</li>
					<li><a href="#">Terms of Use</a></li>
					<li><a href="#">Privacy Policy</a></li>
				</ul>
			</div>
		</div>