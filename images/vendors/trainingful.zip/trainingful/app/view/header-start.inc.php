		<!-- Header -->
		<div id="header-wrapper">
			<div id="header" class="container">
				
				<!-- Logo -->
					<h1 id="logo"><a href="./">trainingful</a></h1>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="left-sidebar.html">Explore Vendors</a></li>
							<li><a href="left-sidebar.html">Explore Categories</a></li>
							<li class="break"><a href="left-sidebar.html">Write a Review</a></li>
							<li>
								<a href="#">Country</a>
								<ul>
									<!--<li><a href="#">Africa</a></li>
									<li><a href="#">Asia</a>
										<ul>
											<li><a href="#">Hong Kong</a></li>
											<li><a href="#">Singapore</a></li>				
										</ul>
									</li>
									<li><a href="#">Australia & Oceania</a>
										<ul>
											<li><a href="#">Australia</a></li>
											<li><a href="#">New Zealand</a></li>				
										</ul>
									</li>
									<li><a href="#">Europe</a>
										<ul>
											<li><a href="#">Denmark</a></li>
											<li><a href="#">France</a></li>
											<li><a href="#">Germany</a></li>
											<li><a href="#">United Kingdom</a></li>
										</ul>
									</li>-->
									<li>
										<a href="">Middle East</a>
										<ul>
											<li><a href="#">Qatar</a></li>
											<li><a href="#">United Arab Emirates</a></li>
										</ul>
									</li>
									<li><a href="#">North America</a>
										<ul>
											<li><a href="#">Canada</a></li>
											<!--<li><a href="#">United States</a></li>-->
										</ul>
									</li>
									<!--<li><a href="#">South America</a></li>-->
									
								</ul>
							</li>
							<li><a href="no-sidebar.html">Sign In</a></li>
						</ul>
					</nav>
			</div>