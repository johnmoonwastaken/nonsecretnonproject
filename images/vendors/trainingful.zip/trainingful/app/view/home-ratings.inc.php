			<!-- Promo -->
			<div id="promo-wrapper">
				<section id="promo">
					<h2>I loved the PMP course -- Sep 20, 2014 <br /> -- Verified LinkedIn User...</h2>
					<a href="#" class="button">See course ratings</a>
				</section>
			</div>
			
		<!-- Features 2 -->
			<div class="wrapper">
				<section class="container">
<h3 style="text-align:left">Top Rated</h3>
					<header class="major">
						<h2>Sed magna consequat lorem curabitur tempus</h2>
						<p>Elit aliquam vulputate egestas euismod nunc semper vehicula lorem blandit</p>
					</header>
					<div class="row features">
						<section class="4u feature">
							<div class="image-wrapper first">
								<a href="#" class="image featured"><img src="images/pic03.jpg" alt="" /></a>
							</div>
							<p>Lorem ipsum dolor sit amet consectetur et sed adipiscing elit. Curabitur 
							vel sem sit dolor neque semper magna lorem ipsum.</p>
						</section>
						<section class="4u feature">
							<div class="image-wrapper">
								<a href="#" class="image featured"><img src="images/pic04.jpg" alt="" /></a>
							</div>
							<p>Lorem ipsum dolor sit amet consectetur et sed adipiscing elit. Curabitur 
							vel sem sit dolor neque semper magna lorem ipsum.</p>
						</section>
						<section class="4u feature">
							<div class="image-wrapper">
								<a href="#" class="image featured"><img src="images/pic05.jpg" alt="" /></a>
							</div>
							<p>Lorem ipsum dolor sit amet consectetur et sed adipiscing elit. Curabitur 
							vel sem sit dolor neque semper magna lorem ipsum.</p>
						</section>
					</div>
					<ul class="actions major">
						<li><a href="#" class="button">Elevate my awareness</a></li>
					</ul>
				</section>
			</div>