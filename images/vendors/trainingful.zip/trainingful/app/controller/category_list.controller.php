<?php

$templateFields = array();



displayTemplate('category_list', $templateFields);