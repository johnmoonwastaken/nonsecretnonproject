<?php

$templateFields = array();



displayTemplate('admin', $templateFields);