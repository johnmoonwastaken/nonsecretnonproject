<?php

$templateFields = array();



displayTemplate('search', $templateFields);