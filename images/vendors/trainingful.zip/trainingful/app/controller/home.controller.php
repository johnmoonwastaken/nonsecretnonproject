<?php

$templateFields = array();



displayTemplate('home', $templateFields);