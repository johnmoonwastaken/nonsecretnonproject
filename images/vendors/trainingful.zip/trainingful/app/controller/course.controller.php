<?php

$templateFields = array();



displayTemplate('course', $templateFields);